import React from 'react';
import "./gallery.css";
export default function Gallery() {
  return (
<div >
  <h1 className='tit1'>GALLERY</h1>
  <h2 className='tit2'>Our Car Collections</h2>
  <div className='tit3'>
    HOME
  </div>
  <div>
         <img className='img1' src="https://route66cars.in/storage/app/uploads/public/619/509/11b/61950911b430f922152979.jpg" alt="React Logo" />
         <img className='img2' src="https://route66cars.in/storage/app/uploads/public/619/509/12e/61950912ebe9c126201212.jpg" alt="React Logo" />
         <img className='img3' src="https://images.news18.com/ibnlive/uploads/2019/09/Contessa-Modified.png?impolicy=website&width=510&height=356" alt="master the blaster" />
         <img className='img4' src="https://route66cars.in/storage/app/uploads/public/619/509/5eb/6195095eb2596560841109.jpg" alt="React Logo" />
         <img className='img5' src="https://tamil.behindtalkies.com/wp-content/uploads/sites/4/2018/01/Karakattakaran-car.jpg" alt="Soppana sundhari😍" />
         <img className='img6' src="http://www.boomcars.in/images/singler-car/427_04.jpg" alt="React Logo" />
         <img className='img7' src="http://www.boomcars.in/images/singler-car/425_05.jpg" alt="React Logo" />
         <img className='img8' src="http://www.link4uglobal.in/uploads/cars/ea6b8522403dea4de5e682127043f5d5.jpg" alt="React Logo" />
         <img className='img9' src="http://www.boomcars.in/images/singler-car/388_img3.jpg" alt="React Logo" />
         <img className='img10' src={require("D:/React/reactproject/src/Screenshot_20221206_125212.png")} alt="React Logo" />
         <img className='img11' src={require("D:/React/reactproject/src/Screenshot_20221206_072621.png")} alt="React Logo" />
         <img className='img12' src={require("D:/React/reactproject/src/ocatne_gold_whirte-removebg-preview.png")} alt="react logo"/>
         <img className='img13' src="https://route66cars.in/storage/app/uploads/public/636/8de/089/6368de08932a2592346333.jpeg" alt="React Logo" />
         <img className='img14' src="https://imgd.aeplcdn.com/1024x768/cw/ucp/stockApiImg/6HCWWEF_a97ece561fcb48a2b1545b63e28b3a96_1_26051885.jpg?q=75" alt="React Logo" />
         <img className='img15' src="https://imgd.aeplcdn.com/1024x768/cw/ucp/stockApiImg/N76Z1Q8_1131fbb3db444622ac8898418feb612b_1_26042170.jpg?q=75" alt="React Logo" />
         <img className='img16' src="https://imgd.aeplcdn.com/1024x768/cw/ucp/stockApiImg/RJ9DEU5_c8393789788542a0a5cf2f001303256f_1_26048537.jpg?q=75" alt="React Logo" />
         <img className='img17' src="https://imgd-ct.aeplcdn.com/1024x768/cw/ucp/stockApiImg/AB80WVU_83e374d7abbc4d459ea2249059b84353_1_26150569.jpg?q=75" alt="React Logo" />
         <img className='img18' src="https://imgd.aeplcdn.com/1024x768/cw/ucp/stockApiImg/Y93YBNH_de265104ea8d4008b888faf3729d5ce8_1_26150753.jpg?q=75" alt="React Logo" />
      </div>
  </div>


    
  )
}