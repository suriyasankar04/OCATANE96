import React from 'react';
import Gallery from './gallery';
import './gallery';
function App() {
  return (
    <div>
      <Gallery/>
       
    </div>

  )
}

export default App;
